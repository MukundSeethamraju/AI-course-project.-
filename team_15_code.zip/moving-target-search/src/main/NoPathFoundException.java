package main;

public class NoPathFoundException extends Exception{
}

package main;

/**
 * interface for objects that can count the number of expanded nodes
 */
public interface ExpandCounter {
    void countNodeExpand();
}
